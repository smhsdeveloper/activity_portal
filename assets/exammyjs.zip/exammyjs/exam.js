var app = angular.module('exam', ['timer', 'firebase']);
app.controller('examController', ['$scope', '$http', '$firebaseObject', function($scope, $http, $firebaseObject) {
        $scope.examdata = {
            "companyname": "Mittal Processors Private Limited.",
            "companylogo": "examimages/logo.gif",
            "empname": "Ashish Gupta",
            "empmob": "7503350470",
            "examstatus": "NOTSTART",
            "questionset": [{
                    "papername": "Apti Round",
                    "paperduration": "1454686200000",
                    "userDuration": "1454686200000",
                    "queitionsArr": [
                        {
                            "serialNo": "1",
                            "quetionType": "MUL",
                            "que": "How many legs of cow ?",
                            "options": [
                                {
                                    "val": "options1",
                                    "sts": false
                                },
                                {
                                    "val": "options2",
                                    "sts": false
                                },
                                {
                                    "val": "options3",
                                    "sts": false
                                },
                                {
                                    "val": "options4",
                                    "sts": false
                                }

                            ]
                        },
                        {
                            "serialNo": "2",
                            "quetionType": "SUB",
                            "que": "How many legs of cow ?",
                            "letternumber": "250",
                            "selctedAns": "this is an essay."

                        }
                    ]
                },
                {
                    "papername": "Technical Round",
                    "paperduration": "1454686200000",
                    "userDuration": "1454686200000",
                    "queitionsArr": [
                        {
                            "serialNo": "1",
                            "quetionType": "OBJ",
                            "que": "How many legs of Technical cow ?",
                            "options": [
                                {
                                    "val": "options1"
                                },
                                {
                                    "val": "options2"
                                },
                                {
                                    "val": "options3"
                                },
                                {
                                    "val": "options4"
                                }

                            ]
                        },
                        {
                            "serialNo": "1",
                            "quetionType": "MUL",
                            "que": "How many legs of cow ?",
                            "options": [
                                {
                                    "val": "options1",
                                    "sts": false
                                },
                                {
                                    "val": "options2",
                                    "sts": false
                                },
                                {
                                    "val": "options3",
                                    "sts": false
                                },
                                {
                                    "val": "options4",
                                    "sts": false
                                }

                            ]
                        },
                        {
                            "serialNo": "2",
                            "quetionType": "SUB",
                            "que": "How many legs of cow ?",
                            "letternumber": "250",
                            "selctedAns": "this is an essay."

                        }
                    ]
                },
                {
                    "papername": "Essay",
                    "paperduration": "1454686200000",
                    "userDuration": "1454686200000",
                    "queitionsArr": [
                        {
                            "serialNo": "3",
                            "quetionType": "SUB",
                            "que": "How many legs of cow ?",
                            "letternumber": "250",
                            "selctedAns": "this is an essay."

                        },
                        {
                            "serialNo": "3",
                            "quetionType": "SUB",
                            "que": "How many legs of cow ?",
                            "letternumber": "250",
                            "selctedAns": "this is an essay."

                        }

                    ]
                }
            ]

        };
        
        $scope.questiontype = questype;
        $scope.examkey = examkey;
        $scope.indexcount = 0;
        $scope.nextquestion = function(queSetIndex, queIndex) {
            $scope.indexcount = queIndex + 1;
            console.log($scope.examdata.questionset[queIndex].queitionsArr[queSetIndex].quetionType);
//            console.log($scope.indexcount);
        }
        $scope.skipquestion = function(questionindex, setindex) {
            $scope.examdata.questionset[setindex].queitionsArr[questionindex].status = 'skip';
            $scope.indexcount = questionindex + 1;
        }
        $scope.prequestion = function(queIndex) {
            if (queIndex == '0') {
                $scope.indexcount = 0;
            } else {
                $scope.indexcount = queIndex - 1;
            }

        };
        $scope.startExam = function() {
            $scope.examdata.examstatus = 'START';
        };
        $scope.changeOption = function(thisval) {
            console.log(thisval);
        }
        $scope.submit = function() {
            $scope.examdata.examstatus = 'MANUALSUBMIT';
        }
        var ref = new Firebase("https://obxybbxyx0d.firebaseio-demo.com/obxybbxyx0d");
//        // download the data into a local object
        $scope.data = $firebaseObject(ref);
//        console.log($scope.data);

    }]

        );
